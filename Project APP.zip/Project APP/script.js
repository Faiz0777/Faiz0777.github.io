function checkLogin() {
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    if (username === 'FAIZ PACHU' && password === 'FAIZ PACHU') {
        document.getElementById('login-section').classList.add('hidden');
        document.getElementById('main-menu').classList.remove('hidden');
    } else {
        alert('Incorrect Username or Password');
    }
}

function navigate(section) {
    document.querySelectorAll('div[id$="-projects"], #main-menu').forEach(div => {
        div.classList.add('hidden');
    });
    document.getElementById(section).classList.remove('hidden');
}

function showPopup(type) {
    const popupContent = document.getElementById('popup-content');
    if (type === 'previous') {
        popupContent.innerHTML = `
            <h2>Add New Project</h2>
            <input type="file" id="new-project-file" accept="video/*,image/*">
            <button onclick="addProject('previous')" class="modern-button">Add Project</button>
        `;
    } else if (type === 'upcoming') {
        popupContent.innerHTML = `
            <h2>Add Upcoming Project</h2>
            <input type="text" id="project-title" placeholder="Title" class="modern-input">
            <input type="text" id="project-description" placeholder="Description" class="modern-input">
            <select id="video-type" class="modern-input">
                <option value="shorts">SHORTS</option>
                <option value="video">VIDEO</option>
                <option value="live">LIVE</option>
                <option value="podcast">PODCAST</option>
            </select>
            <select id="video-quality" class="modern-input">
                <option value="720p">720P</option>
                <option value="1080p">1080P</option>
                <option value="2k">2K</option>
                <option value="4k">4K</option>
            </select>
            <input type="date" id="upload-date" class="modern-input">
            <button onclick="addProject('upcoming')" class="modern-button">Add Project</button>
        `;
    }
    document.getElementById('popup').classList.remove('hidden');
}

function closePopup() {
    document.getElementById('popup').classList.add('hidden');
}

function addProject(type) {
    let projectList, newProject;
    if (type === 'previous') {
        const file = document.getElementById('new-project-file').files[0];
        if (file) {
            projectList = document.getElementById('previous-project-list');
            newProject = document.createElement('div');
            newProject.classList.add('project-item');
            newProject.innerHTML = `
                <p>${file.name}</p>
                <video controls src="${URL.createObjectURL(file)}"></video>
                <button class="delete-button" onclick="deleteProject(this)">X</button>
            `;
        }
    } else if (type === 'upcoming') {
        const title = document.getElementById('project-title').value;
        const description = document.getElementById('project-description').value;
        const videoType = document.getElementById('video-type').value;
        const videoQuality = document.getElementById('video-quality').value;
        const uploadDate = document.getElementById('upload-date').value;

        if (title && description && videoType && videoQuality && uploadDate) {
            projectList = document.getElementById('upcoming-project-list');
            newProject = document.createElement('div');
            newProject.classList.add('project-item');
            newProject.innerHTML = `
                <p><strong>Title:</strong> ${title}</p>
                <p><strong>Description:</strong> ${description}</p>
                <p><strong>Type:</strong> ${videoType}</p>
                <p><strong>Quality:</strong> ${videoQuality}</p>
                <p><strong>Upload Date:</strong> ${uploadDate}</p>
                <button class="delete-button" onclick="deleteProject(this)">X</button>
            `;
        }
    }

    if (newProject) {
        projectList.appendChild(newProject);
        closePopup();
    } else {
        alert('Please fill in all fields');
    }
}

function deleteProject(element) {
    const projectItem = element.parentElement;
    projectItem.remove();
}
